/* Same GA4 measurement ID as the previous live site. No conversion is claimed merely for opening WhatsApp. */
(function(){
  'use strict';
  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const ga = (event, data={}) => { if(typeof window.gtag === 'function') window.gtag('event', event, data); };
  const menu = $('#menuToggle'), links = $('#navLinks');
  if(menu && links){
    menu.addEventListener('click',()=>{
      const expanded=menu.getAttribute('aria-expanded')==='true';
      menu.setAttribute('aria-expanded',String(!expanded));links.classList.toggle('open',!expanded);
      document.body.classList.toggle('menu-open',!expanded);
    });
    $$('#navLinks a').forEach(a=>a.addEventListener('click',()=>{
      links.classList.remove('open');document.body.classList.remove('menu-open');menu.setAttribute('aria-expanded','false');
    }));
  }
  function getAttribution(){const p=new URLSearchParams(location.search);const o={};
    ['utm_source','utm_medium','utm_campaign','utm_content','utm_term','gclid'].forEach(k=>{
      const v=p.get(k); if(v) {o[k]=v.slice(0,150);try{sessionStorage.setItem('aar_'+k,o[k])}catch(e){}}
      else {try{o[k]=sessionStorage.getItem('aar_'+k)||''}catch(e){o[k]=''}}
    });return o;
  }
  const attribution=getAttribution();
  $$('[data-lead-form]').forEach(form=>{
    Object.entries(attribution).forEach(([k,v])=>{const hidden=form.querySelector('input[name="'+k+'"]');if(hidden)hidden.value=v;});
    const path=form.querySelector('input[name="page_path"]');if(path)path.value=location.pathname;
    form.addEventListener('submit',e=>{
      const honeypot=$('[name="website"]',form);
      if(honeypot && honeypot.value){e.preventDefault();return;}
      if(!form.checkValidity())return;
      const btn=$('[type="submit"]',form);
      if(btn){btn.disabled=true;btn.textContent='جارٍ تحويل الطلب إلى نظام التسجيل…';}
      try{sessionStorage.setItem('aar_form_pending','1')}catch(err){}
      ga('lead_form_submit_attempt', {form_name:'alam_al_roum_phase2', page_path:location.pathname});
      // Native POST to the previously configured Google Apps Script. The backend must confirm success.
      // DO NOT fire generate_lead here: a submission attempt does not prove successful receipt.
      // On network errors, the receiving endpoint controls its own response and any return redirect.
    },{once:true});
  });
  $$('a[href*="wa.me/"]').forEach(a=>{
    a.addEventListener('click',()=>ga('whatsapp_click',{link_text:(a.textContent||'').trim().slice(0,70),page_path:location.pathname}));
    // If no prepared message is supplied, generate one without sensitive form inputs.
    if(!new URL(a.href).searchParams.has('text')){
      const msg='مرحبًا، أريد متابعة الإعلان عن الطرح الثاني لمشروع علم الروم. مصدر الاستفسار: '+location.hostname+' / '+location.pathname+(attribution.utm_campaign?' — الحملة: '+attribution.utm_campaign:'');
      a.href='https://wa.me/201000001802?text='+encodeURIComponent(msg);
    }
  });
  $$('[data-interest-click]').forEach(a=>a.addEventListener('click',()=>ga('register_interest_click',{page_path:location.pathname})));
})();
