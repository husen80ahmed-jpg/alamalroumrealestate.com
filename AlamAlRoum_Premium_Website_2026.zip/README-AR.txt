حزمة الموقع premium — alamalroumrealestate.com — 19 أكتوبر 2026

1) ارفع محتويات هذا المجلد كما هي إلى جذر استضافة الدومين، مع الاحتفاظ بمجلدات assets/ وresidences/ وprivacy/.
   إذا كانت الاستضافة تسمى public_html ارفع الملفات داخل public_html مباشرة.
2) تأكد من عمل هذه الروابط:
   https://alamalroumrealestate.com/
   https://alamalroumrealestate.com/residences/
   https://alamalroumrealestate.com/privacy/
   https://alamalroumrealestate.com/sitemap.xml
   https://alamalroumrealestate.com/robots.txt
3) Google Analytics 4: تم الحفاظ على المعرّف G-NHJ1NH0NT4 في الصفحات كلها.
   أحداث مخصصة: register_interest_click, whatsapp_click, lead_form_submit_attempt.
   لا تعتبر هذه الأحداث مبيعات أو تسجيلات مؤكدة.
4) نموذج الاهتمام يستخدم عنوان Google Apps Script الموجود في كودك القديم:
   https://script.google.com/macros/s/AKfycbyU-xDSiyxG6YlIClvO-JHCALYuxSwTDV8DVx_sZooJHbdGEEG7MEvC33lWJjwWph-R/exec
   لم نعدل خدمة Apps Script ولم يتم التحقق من استقبالها للطلبات. يجب اختبارها ببيانات تجربة
   والتأكد من أن أسماء الحقول الإضافية لا تعطل النموذج وأن الرد ينجح.
   لإظهار صفحة الشكر المؤكدة يجب أن يعيد Apps Script توجيه المتصفح إلى:
   https://alamalroumrealestate.com/thank-you.html?submitted=1
   فقط بعد حفظ الطلب بنجاح، وليس بمجرد ضغط زر الإرسال.
   ملاحظة تقنية: الصفحة تتطلب وجود جلسة بدأ فيها المستخدم إرسال الطلب، إضافة إلى ?submitted=1.
   هذا فلتر ضد الزيارات المباشرة لكنه ليس بديلًا عن تأكيد خادمي موثق و lead_id حقيقي.
5) رقم واتساب المستخدم من الكود الأصلي: +201000001802. راجعه قبل النشر.
6) لا تضع صفحة شكر في Sitemap: هي noindex.
7) تم الحفاظ على المسار القديم /residences/ وتحسينه حتى لا تفقد الزوار والروابط إليه.
8) تحديث حالة الطرح: عبارة SOLD OUT حسب إفادتك ومعلومات التسويق بتاريخ 19 أكتوبر 2026.
   لا يوجد في المصادر التي تمت مراجعتها موعد رسمي محسوم للطرح الثاني.
9) روابط مصادر الحقائق داخل الموقع؛ الصور التخطيطية مستخدمة من ملفات موقعك القديم.
   تحقق من حقوق الاستخدام التجاري للصور قبل النشر العام.
10) بعد النشر: Google Search Console > Sitemaps > أضف sitemap.xml، ثم افحص الصفحة الرئيسية وصفحة الوحدات.

حقوق وتوضيح: الموقع مستقل وغير تابع لشركة الديار القطرية؛ لا يُستخدم شعار المطور بما يوحي بصفة رسمية.
